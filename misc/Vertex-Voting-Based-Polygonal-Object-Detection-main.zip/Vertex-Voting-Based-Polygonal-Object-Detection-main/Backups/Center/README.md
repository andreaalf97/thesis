1.split data(will automatically put test data into map/imput/images-optional for future evaluation use)
2.train
3.test(will write result into map/input for evaluation use)

# Mind the difference between coordinate systems used in shapely(righy:x up:y), cv2, plt and label
# Coordinate system used in this network is (down:x right:y)